package com.object.azienda.utility;

import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;

public class Utils {
    public static void infoErrorBox(String message, String headerText, String title) {
        Alert alert;
        if (title.equalsIgnoreCase("INFO")) {
            alert = new Alert(Alert.AlertType.INFORMATION);
            TextArea textArea = new TextArea(message);
            textArea.setEditable(false); // il testo non può essere modificato
            textArea.setWrapText(true);  // va a capo
            textArea.setMaxWidth(Double.MAX_VALUE);
            textArea.setMaxHeight(Double.MAX_VALUE);

            // Scrollbars visibili solo quando necessario
            textArea.setPrefWidth(600);
            textArea.setPrefHeight(300);

            // Imposta il TextArea come contenuto dell'alert
            alert.getDialogPane().setContent(textArea);

        } else {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(message);
        }

        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.show();
    }

}
