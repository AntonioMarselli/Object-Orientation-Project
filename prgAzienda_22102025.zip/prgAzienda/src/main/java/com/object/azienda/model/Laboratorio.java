package com.object.azienda.model;

public class Laboratorio {
    private String topic;
    private String[] impiegati;
    private String cod_responsabile_senior;
    private String cod_lab;
    private String nome;

    public Laboratorio() {

    }

    public String getTopic() {
        return topic;
    }

    private void setTopic(String topic) {
        this.topic = topic;
    }

    public String[] getImpiegati() {
        return impiegati;
    }

    private void setImpiegati(String[] impiegati) {
        this.impiegati = impiegati;
    }

    public String getCod_responsabile_senior() {
        return cod_responsabile_senior;
    }

    private void setCod_responsabile_senior(String cod_responsabile_senior) {
        this.cod_responsabile_senior = cod_responsabile_senior;
    }

    public String getCod_lab() {
        return cod_lab;
    }

    private void setCod_lab(String cod_lab) {
        this.cod_lab = cod_lab;
    }

    public String getNome() {
        return nome;
    }

    private void setNome(String nome) {
        this.nome = nome;
    }

    public Laboratorio(String cod_lab, String topic, String nome, String cod_impiegati, String cod_responsabile_senior) {
        this.cod_lab = cod_lab;
        this.topic = topic;
        this.nome = nome;

        String[] parts = cod_impiegati.split(";");
        for (int i = 0; i < parts.length; i++) {
            parts[i] = parts[i].trim();
        }
        this.impiegati = parts;
        this.cod_responsabile_senior = cod_responsabile_senior;
    }

}
