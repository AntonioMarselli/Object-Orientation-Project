package com.object.azienda.dao;


import com.object.azienda.model.Impiegato;

import java.sql.*;
import java.sql.Date;
import java.util.*;


public class ImpiegatoDAO {

    public boolean existsByCod(String codiceImpiegatoInput) {

        String QUERY = "select count(*) from impiegato where codice_impiegato=?";

        try (Connection connection = DbConnectionDAO.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            preparedStatement.setString(1, codiceImpiegatoInput);
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1);
                return count > 0;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }


    public ArrayList<Impiegato> getAllImpiegati() {

        String QUERY = "select * from impiegato order by codice_impiegato";

        try (Connection connection = DbConnectionDAO.connect();

             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            ArrayList<Impiegato> impiegati = new ArrayList<>();
            while (rs.next()) {
                // INFO IMPIEGATI
                String cod = rs.getString("codice_impiegato");
                String nome = rs.getString("nome");
                String cognome = rs.getString("cognome");
                String cf = rs.getString("codice_fiscale");

                Impiegato impiegato = new Impiegato(nome, cognome, cod, cf);
                impiegati.add(impiegato);
            }
            return impiegati;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Impiegato getImpiegatoByCod(String impiegatoCod) {

        String QUERY = "select * from impiegato where codice_impiegato=?";

        try (Connection connection = DbConnectionDAO.connect();

             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            preparedStatement.setString(1, impiegatoCod);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            Impiegato impiegato = null;
            while (rs.next()) {
                boolean dirigente = rs.getBoolean("dirigente");
                String codice = rs.getString("codice_impiegato");

                // INFO IMPIEGATO

                String nome = rs.getString("nome");
                String cognome = rs.getString("cognome");
                String email = rs.getString("email");
                String cod_fiscale = rs.getString("codice_fiscale");
                Date data_nascita = rs.getDate("data_di_nascita");
                Date data_assunzione = rs.getDate("data_assunzione");
                String ruolo = rs.getString("ruolo");
                System.out.println(codice + "\t" + nome + "\t" + cognome + "\t\t" + data_nascita);

                impiegato = new Impiegato(nome, cognome, data_nascita, cod_fiscale, data_assunzione, codice, dirigente,
                        email, ruolo);
                }
                return impiegato;

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
    }


    public Map<Date, String> getCarrieraByImpiegatoCod(String codImpiegato) {

        String QUERY = "select * from carriera where cod_impiegato=? " +
                " order by data_modifica asc";

        try (Connection connection = DbConnectionDAO.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            preparedStatement.setString(1, codImpiegato);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            Map<Date, String> carriera = new LinkedHashMap<>();
            //HashMap<Date, String> carriera = new HashMap<>();
            while (rs.next()) {
                Date data_modifica = rs.getDate("data_modifica");
                String old_ruolo = rs.getString("old_ruolo");
                String new_ruolo = rs.getString("new_ruolo");
                boolean old_dirigente = rs.getBoolean("old_dirigente");
                boolean new_dirigente = rs.getBoolean("new_dirigente");
                if(!new_ruolo.equalsIgnoreCase(old_ruolo))
                    carriera.put(data_modifica, new_ruolo);

                if(new_dirigente != old_dirigente)
                    carriera.put(data_modifica, "DIRIGENTE");

            }
            return carriera;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void setImpiegato(Impiegato impiegato) {

        String insImpiegato = "insert into impiegato " +
                "(codice_impiegato,nome,cognome,data_di_nascita,email,data_assunzione," +
                "codice_fiscale,ruolo, dirigente, data_calcolo_seniority) values (?,?,?,?,?,?,?,?,?,?)";

        try (Connection connection = DbConnectionDAO.connect();

             PreparedStatement preparedStatement = connection.prepareStatement(insImpiegato)) {
            preparedStatement.setString(1, impiegato.getCod_impiegato());
            preparedStatement.setString(2, impiegato.getNome());
            preparedStatement.setString(3, impiegato.getCognome());

            preparedStatement.setDate(4, (java.sql.Date) impiegato.getData_nascita());
            preparedStatement.setString(5, impiegato.getEmail());

            preparedStatement.setDate(6, (java.sql.Date) impiegato.getData_assunzione());

            preparedStatement.setString(7, impiegato.getCod_fiscale());

            preparedStatement.setString(8, impiegato.getRuolo());


            preparedStatement.setBoolean(9, impiegato.isDirigente());

            preparedStatement.setTimestamp(10, new Timestamp(System.currentTimeMillis()));
            System.out.println(preparedStatement);

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void setImpiegatoDirigente(String impiegatoCod) {

        String updDirigente = "update impiegato set dirigente=true where codice_impiegato=?";
        try (Connection connection = DbConnectionDAO.connect();

             PreparedStatement preparedStatement = connection.prepareStatement(updDirigente)) {
            preparedStatement.setString(1, impiegatoCod);

            System.out.println(preparedStatement);

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void updImpiegatoSeniority() {

        String updateString = "Update impiegato set data_calcolo_seniority = ?";

        try (Connection connection = DbConnectionDAO.connect();
             PreparedStatement preparedStatementUpd = connection.prepareStatement(updateString)) {
            preparedStatementUpd.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
            preparedStatementUpd.executeUpdate();
            System.out.println(preparedStatementUpd);

        } catch (
                SQLException e) {
            throw new RuntimeException(e);
        }
    }
}