package com.object.azienda;

import com.object.azienda.dao.ImpiegatoDAO;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

public class AziendaApplication extends Application {
    private static Stage primaryStage;


    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;

        scheduledDailyTask();
        FXMLLoader fxmlLoader = new FXMLLoader(AziendaApplication.class.getResource("azienda-login-view.fxml"));
        Scene scene = new Scene((Parent) fxmlLoader.load(), 1024, 640);

        scene.setFill(Color.valueOf("#FFF"));
        stage.setTitle("AREA ADMIN");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    public static void  changeScene(String fxml) throws IOException {
        Parent pane = FXMLLoader.load(Objects.requireNonNull(AziendaApplication.class.getResource(fxml)));
        primaryStage.getScene().setRoot(pane);
    }

    public void scheduledDailyTask() {
        TimerTask repeatedTask = new TimerTask() {
            public void run() {
                System.out.println("Calcolo Seniority - Task performed on " + new Timestamp(System.currentTimeMillis()));
                ImpiegatoDAO impiegatoDAO = new ImpiegatoDAO();
                impiegatoDAO.updImpiegatoSeniority();
            }
        };
        Timer timer = new Timer("Timer");
        long delay = 1000L;
        long period = 1000L * 60L * 60L * 24L;
        timer.scheduleAtFixedRate(repeatedTask, delay, period);
    }

}