module com.object.azienda {
    requires javafx.controls;
    requires javafx.fxml;

    //requires org.controlsfx.controls;
    //requires com.dlsc.formsfx;
    requires javafx.graphics;
    requires java.sql;

    opens com.object.azienda to javafx.fxml;
    exports com.object.azienda;
    exports com.object.azienda.dao;
    opens com.object.azienda.dao to javafx.fxml;
    exports com.object.azienda.controller;
    opens com.object.azienda.controller to javafx.fxml;
    exports com.object.azienda.model;
    opens com.object.azienda.model to javafx.fxml;
}