package com.object.azienda.model;

public class Progetto {
    private String cup;
    private String nome;
    private String cod_responsabile_dirigente;
    private String cod_referente_scientifico_senior;
    private String cod_lab;

    public String getCup() {
        return cup;
    }

    private void setCup(String cup) {
        this.cup = cup;
    }

    public String getNome() {
        return nome;
    }

    private void setNome(String nome) {
        this.nome = nome;
    }

    public String getCod_responsabile_dirigente() {
        return cod_responsabile_dirigente;
    }

    private void setCod_responsabile_dirigente(String cod_responsabile_dirigente) {
        this.cod_responsabile_dirigente = cod_responsabile_dirigente;
    }

    public String getCod_referente_scientifico_senior() {
        return cod_referente_scientifico_senior;
    }

    private void setCod_referente_scientifico_senior(String cod_referente_scientifico_senior) {
        this.cod_referente_scientifico_senior = cod_referente_scientifico_senior;
    }

    public String getCod_lab() {
        return cod_lab;
    }

    private void setCod_lab(String cod_lab) {
        this.cod_lab = cod_lab;
    }

    public Progetto(String cup, String nome, String cod_responsabile_dirigente, String cod_referente_scientifico_senior, String cod_lab) {
        this.cup = cup;
        this.nome = nome;
        this.cod_responsabile_dirigente = cod_responsabile_dirigente;
        this.cod_referente_scientifico_senior = cod_referente_scientifico_senior;
        this.cod_lab = cod_lab;
    }
}
