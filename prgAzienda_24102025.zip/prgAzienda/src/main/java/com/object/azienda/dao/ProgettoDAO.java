package com.object.azienda.dao;

import com.object.azienda.model.Progetto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProgettoDAO {

    public ArrayList<Progetto> getAllProgetti() {
        String QUERY = "select * from progetto order by cup";

        try (Connection connection = DbConnectionDAO.connect();

             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            ArrayList<Progetto> progetti = new ArrayList<>();
            while (rs.next()) {
                // INFO POGETTI
                String cup = rs.getString("cup");
                String nome = rs.getString("nome");
                String cod_responsabile_senior = rs.getString("cod_referente_scientifico_senior");
                String cod_responsabile_dirigente = rs.getString("cod_responsabile_dirigente");
                String cod_lab = rs.getString("cod_lab");

                Progetto progetto = new Progetto(cup, nome, cod_responsabile_dirigente, cod_responsabile_senior, cod_lab);
                progetti.add(progetto);
            }
            return progetti;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Progetto> getProgettoByCodOrName(String progettoInput) {
        String  QUERY = "select * from progetto where cup like ? or nome like ? order by cup";

        try (Connection connection = DbConnectionDAO.connect();

             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            if (!progettoInput.isEmpty()) {
                preparedStatement.setString(1, "%" + progettoInput + "%");
                preparedStatement.setString(2, "%" + progettoInput + "%");
            }
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            ArrayList<Progetto> progetti = new ArrayList<>();
            while (rs.next()) {
                // INFO POGETTI
                String cup = rs.getString("cup");
                String nome = rs.getString("nome");
                String cod_responsabile_senior = rs.getString("cod_referente_scientifico_senior");
                String cod_responsabile_dirigente = rs.getString("cod_responsabile_dirigente");
                String cod_lab = rs.getString("cod_lab");

                Progetto progetto = new Progetto(cup, nome, cod_responsabile_dirigente, cod_responsabile_senior, cod_lab);
                progetti.add(progetto);
            }
            return progetti;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Progetto> getProgettiByImpiegatoCod(String codImpiegato) {
        String QUERYProg = "select * from progetto where cod_referente_scientifico_senior=? or " +
                "cod_responsabile_dirigente=? order by cup";

        try (Connection connection = DbConnectionDAO.connect();

             PreparedStatement preparedStatement = connection.prepareStatement(QUERYProg)) {
            preparedStatement.setString(1, codImpiegato);
            preparedStatement.setString(2, codImpiegato);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            ArrayList<Progetto> progetti = new ArrayList<>();
            while (rs.next()) {
                // INFO POGETTI
                String cup = rs.getString("cup");
                String nome = rs.getString("nome");
                String cod_responsabile_senior = rs.getString("cod_referente_scientifico_senior");
                String cod_responsabile_dirigente = rs.getString("cod_responsabile_dirigente");
                String cod_lab = rs.getString("cod_lab");

                Progetto progetto = new Progetto(cup, nome, cod_responsabile_dirigente, cod_responsabile_senior, cod_lab);
                progetti.add(progetto);
            }
            return progetti;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}