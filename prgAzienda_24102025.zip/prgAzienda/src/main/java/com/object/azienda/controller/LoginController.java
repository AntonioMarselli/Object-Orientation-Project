package com.object.azienda.controller;

import com.object.azienda.AziendaApplication;
import com.object.azienda.dao.AdminDAO;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField codiceAdmin;

    @FXML
    private TextField passwordField;

    @FXML
    protected void handleLoginButtonAction()  {

        System.out.println("codiceAdmin= "+codiceAdmin.getText());
        System.out.println("password= "+passwordField.getText());

        if (codiceAdmin.getText().isEmpty()) {
            errorBox("Inserisci codice admin", null, "Errore");
            return;
        }
        if (passwordField.getText().isEmpty()) {
            errorBox("Inserisci password", null, "Errore");
            return;
        }

        String codiceAdminInput = codiceAdmin.getText();
        String passwordInput = passwordField.getText();
        AdminDAO adminDAO = new AdminDAO();
        if(!adminDAO.isValidAdminUser(codiceAdminInput, passwordInput)){
            errorBox("Credenziali errate", null, "Errore");
            return;
        }

        try {
                AziendaApplication.changeScene("azienda-menu-view.fxml");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public static void errorBox(String infoMessage, String headerText, String title) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.show();
    }
}