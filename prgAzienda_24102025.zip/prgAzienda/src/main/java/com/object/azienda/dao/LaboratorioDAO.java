package com.object.azienda.dao;

import com.object.azienda.model.Laboratorio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class LaboratorioDAO {

    public ArrayList<Laboratorio> getAllLaboratori() {
        String QUERY = "select * from laboratorio order by cod_lab";

        try(Connection connection = DbConnectionDAO.connect();
            PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            ArrayList<Laboratorio> laboratori = new ArrayList<>();
            while (rs.next()) {
                // INFO LABORATORI
                String cod_lab = rs.getString("cod_lab");
                String topic = rs.getString("topic");
                String nome = rs.getString("nome");
                String cod_impiegato = rs.getString("cod_impiegato");
                String cod_responsabile_senior = rs.getString("cod_responsabile_scientifico_senior");

                Laboratorio laboratorio = new Laboratorio(cod_lab, topic, nome, cod_impiegato, cod_responsabile_senior);
                laboratori.add(laboratorio);
            }
            return laboratori;
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Laboratorio getLaboratorioByCod(String laboratorioCod) {
        String QUERY = "select * from laboratorio where cod_lab=?";

        try(Connection connection = DbConnectionDAO.connect();
            PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            preparedStatement.setString(1, laboratorioCod);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            Laboratorio laboratorio = null;
            if (rs.next()) {
                // INFO LABORATORI
                String cod_lab = rs.getString("cod_lab");
                String topic = rs.getString("topic");
                String nome = rs.getString("nome");
                String cod_impiegato = rs.getString("cod_impiegato");
                String cod_responsabile_senior = rs.getString("cod_responsabile_scientifico_senior");

                laboratorio = new Laboratorio(cod_lab, topic, nome, cod_impiegato, cod_responsabile_senior);
            }
            return laboratorio;
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Laboratorio> getLaboratoriByImpiegatoCod(String codImpiegato) {
        String QUERYLab = "select * from laboratorio where cod_impiegato like ? or " +
                "cod_responsabile_scientifico_senior=? order by cod_lab";

        try(Connection connection = DbConnectionDAO.connect();
            PreparedStatement preparedStatement = connection.prepareStatement(QUERYLab)) {
            preparedStatement.setString(1, "%"+codImpiegato+"%");
            preparedStatement.setString(2, codImpiegato);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            ArrayList<Laboratorio> laboratori = new ArrayList<>();
            while (rs.next()) {
                // INFO LABORATORI
                String cod_lab = rs.getString("cod_lab");
                String topic = rs.getString("topic");
                String nome = rs.getString("nome");
                String cod_impiegato = rs.getString("cod_impiegato");
                String cod_responsabile_senior = rs.getString("cod_responsabile_scientifico_senior");

                Laboratorio laboratorio = new Laboratorio(cod_lab, topic, nome, cod_impiegato, cod_responsabile_senior);
                laboratori.add(laboratorio);
            }
            return laboratori;
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }
    }



}