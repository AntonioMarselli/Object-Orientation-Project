package com.object.azienda.dao;

import java.sql.*;

public class AdminDAO {

    public boolean isValidAdminUser(String codiceAdminInput, String passwordInput)  {
        String QUERY = "select * from admin where codice_admin=? and password=?";

        try (Connection connection = DbConnectionDAO.connect();

             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            preparedStatement.setString(1, codiceAdminInput);
            preparedStatement.setString(2, passwordInput);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            if (!rs.isBeforeFirst()) {
                return false;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return true;
    }

}
