package com.object.azienda.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Impiegato {
    private String nome;
    private String cognome;
    private Date data_nascita;
    private String cod_fiscale;
    private Date data_assunzione;
    private String cod_impiegato;
    private boolean dirigente;
    private String email;

    private String ruolo;
    private ArrayList<Laboratorio> laboratori;
    private ArrayList<Progetto> progetti;

    private Map<java.sql.Date, String> carriera;

    public Impiegato() {

    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public Date getData_nascita() {
        return data_nascita;
    }

    public String getCod_fiscale() {
        return cod_fiscale;
    }

    public Date getData_assunzione() {
        return data_assunzione;
    }

    public String getCod_impiegato() {
        return cod_impiegato;
    }

    public boolean isDirigente() {
        return dirigente;
    }

    public String getEmail() {
        return email;
    }

    public String getRuolo() {
        return ruolo;
    }

    public ArrayList<Laboratorio> getLaboratori() {
        return laboratori;
    }

    public void setLaboratori(ArrayList<Laboratorio> laboratori) {
        this.laboratori = laboratori;
    }

    public ArrayList<Progetto> getProgetti() {
        return progetti;
    }

    public void setProgetti(ArrayList<Progetto> progetti) {
        this.progetti = progetti;
    }

    public Map<java.sql.Date, String> getCarriera() {
        return carriera;
    }

    public void setCarriera(Map<java.sql.Date, String> carriera) {
        this.carriera = carriera;
    }

    public Impiegato(String nome,
                     String cognome,
                     Date data_nascita,
                     String cod_fiscale,
                     Date data_assunzione,
                     String cod_impiegato,
                     boolean dirigente,
                     String email,
                     String ruolo) {
        this.nome = nome;
        this.cognome = cognome;
        this.data_nascita = data_nascita;
        this.cod_fiscale = cod_fiscale;
        this.data_assunzione = data_assunzione;
        this.cod_impiegato = cod_impiegato;
        this.dirigente = dirigente;
        this.email = email;
        this.ruolo = ruolo;
    }

    public Impiegato(String nome, String cognome, String cod_impiegato, String cod_fiscale) {
        this.nome = nome;
        this.cognome = cognome;
        this.cod_impiegato = cod_impiegato;
        this.cod_fiscale = cod_fiscale;
    }

}
