package com.object.azienda.controller;

import com.object.azienda.dao.ImpiegatoDAO;
import com.object.azienda.dao.LaboratorioDAO;
import com.object.azienda.dao.ProgettoDAO;
import com.object.azienda.model.Impiegato;
import com.object.azienda.model.Laboratorio;
import com.object.azienda.model.Progetto;

import com.object.azienda.utility.Utils;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

public class AziendaMenuController {

    @FXML
    private Label lblRuolo;

    @FXML
    private Label lblDirigente;

    @FXML
    private TextField codiceImpiegato;
    @FXML
    private TextField nomeImpiegato;
    @FXML
    private TextField cognomeImpiegato;
    @FXML
    private TextField emailImpiegato;
    @FXML
    private TextField dataAssunzione;
    @FXML
    private TextField dataNascita;
    @FXML
    private TextField cf;

    @FXML
    private TextField codLaboratorio;

    @FXML
    private TextField inputProgetto;

    @FXML
    public Impiegato impiegato=null;


    @FXML
    protected void onViewAllImpiegatiButtonClick() {
        codLaboratorio.setText("");
        inputProgetto.setText("");
        ImpiegatoDAO impiegatoDao = new ImpiegatoDAO();
        ArrayList<Impiegato> impiegati = impiegatoDao.getAllImpiegati();
        StringBuilder textInfoImpiegati = new StringBuilder();
        for (Impiegato impiegato : impiegati) {
            textInfoImpiegati.append("\n").append(impiegato.getCod_impiegato()).append(": ");
            textInfoImpiegati.append(impiegato.getCognome()).append(" ").append(impiegato.getNome()).append(" - ").append(impiegato.getCod_fiscale());
        }
        Utils.infoErrorBox(textInfoImpiegati.toString(), "Impiegati", "Info");
    }

    @FXML
    protected boolean onViewInfoButtonClick() {
        System.out.println("codiceImpiegato= " + codiceImpiegato.getText());

        if (codiceImpiegato.getText().isEmpty()) {
            Utils.infoErrorBox("Inserisci codice impiegato", null, "Errore");
            return false;
        }
        String codiceImpiegatoInput = codiceImpiegato.getText();
        if(impiegato == null || !impiegato.getCod_impiegato().equals(codiceImpiegatoInput)) {
            ImpiegatoDAO impiegatoDao = new ImpiegatoDAO();
            if (!impiegatoDao.existsByCod(codiceImpiegatoInput)) {
                resetForm();
                Utils.infoErrorBox("Codice Impiegato non esistente", null, "Errore");
                return false;
            }

            impiegato = impiegatoDao.getImpiegatoByCod(codiceImpiegatoInput);

            LaboratorioDAO laboratorioDao = new LaboratorioDAO();
            if (impiegato != null) {
                impiegato.setLaboratori(laboratorioDao.getLaboratoriByImpiegatoCod(impiegato.getCod_impiegato()));
            }
            ProgettoDAO progettoDao = new ProgettoDAO();
            if (impiegato != null) {
                impiegato.setProgetti(progettoDao.getProgettiByImpiegatoCod(impiegato.getCod_impiegato()));
            }
        }
        if(impiegato != null) {
            nomeImpiegato.setText(impiegato.getNome());
            cognomeImpiegato.setText(impiegato.getCognome());
            emailImpiegato.setText(impiegato.getEmail());
            dataNascita.setText(impiegato.getData_nascita().toString());
            dataAssunzione.setText(impiegato.getData_assunzione().toString());
            cf.setText(impiegato.getCod_fiscale());
            lblRuolo.setText(impiegato.getRuolo());
            lblDirigente.setText("");
            if (impiegato.isDirigente())
                lblDirigente.setText("DIRIGENTE");
        }
        return true;
    }

    @FXML
    protected void onViewLaboratorioButtonClick() {
        inputProgetto.setText("");
        if (codLaboratorio.getText().isEmpty()) {
            Utils.infoErrorBox("Inserisci codice laboratorio", null, "Errore");
            return;
        }
        LaboratorioDAO laboratorioDao = new LaboratorioDAO();
        Laboratorio laboratorio = laboratorioDao.getLaboratorioByCod(codLaboratorio.getText());
        StringBuilder textInfoLaboratori = new StringBuilder();
        if (laboratorio != null) {
            textInfoLaboratori.append("Laboratorio: ").append(laboratorio.getTopic());
            textInfoLaboratori.append("\n");
            textInfoLaboratori.append(laboratorio.getCod_responsabile_senior()).
                    append(" - ").append("RESPONSABILE SCIENTIFICO SENIOR");
            textInfoLaboratori.append("\n");

            for (String cod : laboratorio.getImpiegati()) {
                textInfoLaboratori.append(cod).append(" - ");
                textInfoLaboratori.append(" - ").append("AFFERENTE");
                textInfoLaboratori.append("\n");
            }
            textInfoLaboratori.append("\n");
            Utils.infoErrorBox(textInfoLaboratori.toString(), "Info Laboratorio " + codLaboratorio.getText(), "Info");
        }else{
            Utils.infoErrorBox("Codice Laboratorio " + codLaboratorio.getText()+ " non esistente", null, "Errore");
        }
    }

    @FXML
    protected void onViewAllLaboratoriButtonClick() {
        codLaboratorio.setText("");
        inputProgetto.setText("");
        LaboratorioDAO laboratorioDao = new LaboratorioDAO();
        ArrayList<Laboratorio> laboratori = laboratorioDao.getAllLaboratori();
        StringBuilder textInfoLaboratori = new StringBuilder();
        for (Laboratorio laboratorio : laboratori) {
            textInfoLaboratori.append("\n").append(laboratorio.getCod_lab()).append(" - ").append(laboratorio.getTopic());
        }
         Utils.infoErrorBox(textInfoLaboratori.toString(), "Info Laboratori - *" + inputProgetto.getText()+"*", "Info");
    }

    @FXML
    protected void onViewProgettoButtonClick() {
        codLaboratorio.setText("");
        if (inputProgetto.getText().isEmpty()) {
             Utils.infoErrorBox("Inserisci cup o nome progetto", null, "Errore");
            return;
        }
        ProgettoDAO progettoDao = new ProgettoDAO();
        ArrayList<Progetto> progetti = progettoDao.getProgettoByCodOrName(inputProgetto.getText());

        StringBuilder textInfoProgetti = new StringBuilder();
        int i = 0;
        for (Progetto progetto : progetti) {
            i++;
            textInfoProgetti.append("\n#").append(i).append(":")
                    .append("\n").append("Progetto: ").append(progetto.getCup()).
                    append(" ").append(progetto.getNome()).append("\n");
            textInfoProgetti.append(progetto.getCod_referente_scientifico_senior()).append(" - ").append("REFERENTE SENIOR");
            textInfoProgetti.append("\n");
            textInfoProgetti.append(progetto.getCod_responsabile_dirigente()).append(" - ").append("RESPONSABILE DIRIGENTE");
            textInfoProgetti.append("\n");

            String[] parts = progetto.getCod_lab().split(";");
            if (parts != null){
                textInfoProgetti.append("Al progetto lavorano i seguenti laboratori:");
                textInfoProgetti.append("\n");
                LaboratorioDAO laboratorioDao = new LaboratorioDAO();
                for (int j = 0; j < parts.length; j++) {
                    parts[j] = parts[j].trim();
                    Laboratorio lab = laboratorioDao.getLaboratorioByCod(parts[j]);
                    if(lab != null)
                        textInfoProgetti.append("\t").append(parts[j]).append(" - ").append(lab.getTopic());
                    textInfoProgetti.append("\n");
                }
             }
             textInfoProgetti.append("\n");
        }
        if(!progetti.isEmpty())
            Utils.infoErrorBox(textInfoProgetti.toString(), "Info progetto - *" + inputProgetto.getText()+"*", "Info");
        else {
            Utils.infoErrorBox("Nessun progetto esistente con il filtro inserito.", null, "Errore");
        }

    }


    @FXML
    protected void onViewAllProgettiButtonClick() {

        codLaboratorio.setText("");
        inputProgetto.setText("");
        ProgettoDAO progettoDao = new ProgettoDAO();
        ArrayList<Progetto> progetti = progettoDao.getAllProgetti();
        StringBuilder textInfoProgetti = new StringBuilder();
        for (Progetto progetto : progetti) {
            textInfoProgetti.append("\n").append(progetto.getCup()).
                    append(" - ").append(progetto.getNome());
        }
         Utils.infoErrorBox(textInfoProgetti.toString(), "Progetti", "Info");
    }

    private void printLaboratoriImpiegato(String codImpiegato, String msgError){

        if(impiegato.getLaboratori()== null || impiegato.getLaboratori().isEmpty()){
             Utils.infoErrorBox(msgError, "Info Laboratori", "Info");
            return;
        }
        StringBuilder textInfoLaboratori = new StringBuilder();
        int i=0;
        for (Laboratorio laboratorio : impiegato.getLaboratori()){
                i++;
                textInfoLaboratori.append("\n#").append(i).append(": ").append(laboratorio.getCod_lab())
                        .append("\n").append("Laboratorio: ").append(laboratorio.getTopic());

                if (laboratorio.getCod_responsabile_senior().equals(codImpiegato))
                    textInfoLaboratori.append(" come ").append("RESPONSABILE SCIENTIFICO SENIOR");
                if (Arrays.asList(laboratorio.getImpiegati()).contains(codImpiegato))
                    textInfoLaboratori.append(" come ").append("AFFERENTE");
            textInfoLaboratori.append("\n");
        }
         Utils.infoErrorBox(textInfoLaboratori.toString(), "Info Laboratori del codice impiegato: " + codImpiegato, "Info");


    }

    private void printProgettiImpiegato(String codImpiegato, String msgError){

        if(impiegato ==  null ) {
            if(!onViewInfoButtonClick())
                return;
        }

        StringBuilder textInfoProgetti = new StringBuilder();
        int i=0;
        if(impiegato.getProgetti()== null || impiegato.getProgetti().isEmpty()){
             Utils.infoErrorBox(msgError, "Info Progetti", "Info");
            return;
        }

        for (Progetto progetto : impiegato.getProgetti()){
                i++;
                textInfoProgetti.append("\n#").append(i).append(":")
                        .append("\n").append("Progetto: ").append(progetto.getCup()).
                        append(" ").append(progetto.getNome());

                if (progetto.getCod_responsabile_dirigente().equals(impiegato.getCod_impiegato()))
                    textInfoProgetti.append(" come ").append("RESP. DIRIGENTE");
                else
                    textInfoProgetti.append(" come ").append("REF. SCIENTIFICO SENIOR");
            textInfoProgetti.append("\n");
        }
         Utils.infoErrorBox(textInfoProgetti.toString(), "Info progetti del codice impiegato: " + codImpiegato, "Info");
    }


    private void printCarriera(){

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        StringBuilder textInfoCarriera = new StringBuilder();

        for (Map.Entry<java.sql.Date, String> carrieraItem : impiegato.getCarriera().entrySet()) {
            java.util.Date data = carrieraItem.getKey();
            String descrizione = carrieraItem.getValue();
            textInfoCarriera.append("\n").append(sdf.format(data)).append("\t").append(descrizione);
        }

         Utils.infoErrorBox(textInfoCarriera.toString(), "Info Carriera - " + impiegato.getCod_impiegato(), "Info");

    }

    @FXML
    protected void onAddImpiegatoButtonClick() {
        if (codiceImpiegato.getText().isEmpty()) {
             Utils.infoErrorBox("Inserisci codice impiegato", null, "Errore");
            return;
        }

        if (dataAssunzione.getText().isEmpty()) {
             Utils.infoErrorBox("Inserisci data di Assunzione", null, "Errore");
            return;
        }

        String codiceImpiegatoInput = codiceImpiegato.getText();
        ImpiegatoDAO impiegatoDao = new ImpiegatoDAO();
        if(impiegatoDao.existsByCod(codiceImpiegatoInput)){
            resetForm();
             Utils.infoErrorBox("Codice Impiegato già esistente", null, "Errore");
            return;
        }

            LocalDate dataNascitaLocal = LocalDate.parse(dataNascita.getText());
            Date sqlDataNascita = Date.valueOf(dataNascitaLocal);

            // Conversione corretta della data di nascita
            LocalDate dataAssunzioneLocal = LocalDate.parse(dataAssunzione.getText());
            Date sqlDataAssunzione = Date.valueOf(dataAssunzioneLocal);

            LocalDate oggi = LocalDate.now();
            Period periodo = Period.between(LocalDate.from(LocalDate.parse(dataAssunzione.getText())), oggi);
            int anniPassati = periodo.getYears();
            String ruolo;

            if (anniPassati >= 7) {
                ruolo="SENIOR";
            } else if (anniPassati >= 3) {
                ruolo="MIDDLE";
            } else {
                ruolo="JUNIOR";
            }

            impiegato = new Impiegato(nomeImpiegato.getText(), cognomeImpiegato.getText(), sqlDataNascita, cf.getText(),
                    sqlDataAssunzione, codiceImpiegatoInput, false, emailImpiegato.getText(), ruolo);

            impiegatoDao.setImpiegato(impiegato);
            Utils.infoErrorBox("Impiegato inserito con successo", null, "Info");

    }

    @FXML
    protected void onDoDirigenteButtonClick() {
        if (codiceImpiegato.getText().isEmpty()) {
             Utils.infoErrorBox("Inserisci codice impiegato", null, "Errore");
            return;
        }
        String codiceImpiegatoInput = codiceImpiegato.getText();

        if (impiegato==null || !impiegato.getCod_impiegato().equals(codiceImpiegato.getText())) {
            if(!onViewInfoButtonClick())
                return;
        }
        if (impiegato.isDirigente()) {
             Utils.infoErrorBox("L'impiegato "+ codiceImpiegatoInput + " è già dirigente", null, "Errore");
            return;
        }
        ImpiegatoDAO impiegatoDao = new ImpiegatoDAO();
        impiegatoDao.setImpiegatoDirigente(codiceImpiegato.getText());
        impiegato = null;
        onViewInfoButtonClick();
    }


    @FXML
    protected void onViewLaboratoriButtonClick()  {
        if (codiceImpiegato.getText().isEmpty()) {
             Utils.infoErrorBox("Inserisci codice impiegato", null, "Errore");
            return;
        }
        if (impiegato==null || !impiegato.getCod_impiegato().equals(codiceImpiegato.getText())) {
            if(!onViewInfoButtonClick())
                return;
        }

        printLaboratoriImpiegato(codiceImpiegato.getText(),
                "L'impiegato "+ codiceImpiegato.getText() + " non lavora presso alcun laboratorio");

    }

    @FXML
    protected void onViewProgettiButtonClick()  {
        if (codiceImpiegato.getText().isEmpty()) {
             Utils.infoErrorBox("Inserisci codice impiegato", null, "Errore");
            return;
        }
        if (impiegato==null || !impiegato.getCod_impiegato().equals(codiceImpiegato.getText())) {
            if(!onViewInfoButtonClick())
                return;
        }

        printProgettiImpiegato(codiceImpiegato.getText(),"L'impiegato "+ codiceImpiegato.getText() + " non lavora presso alcun progetto");

    }

    @FXML
    protected void onViewCarrieraButtonClick(){
        if (codiceImpiegato.getText().isEmpty()) {
             Utils.infoErrorBox("Inserisci codice impiegato", null, "Errore");
            return;
        }
        if (impiegato==null || !impiegato.getCod_impiegato().equals(codiceImpiegato.getText())) {
            if(!onViewInfoButtonClick())
                return;
        }
        ImpiegatoDAO impiegatoDao = new ImpiegatoDAO();
        impiegato.setCarriera(impiegatoDao.getCarrieraByImpiegatoCod(codiceImpiegato.getText()));
        printCarriera();

    }

        private void resetForm(){
        nomeImpiegato.setText("");
        cognomeImpiegato.setText("");
        emailImpiegato.setText("");
        dataNascita.setText("");
        dataAssunzione.setText("");
        cf.setText("");
        lblRuolo.setText("");
        lblDirigente.setText("");
    }

}